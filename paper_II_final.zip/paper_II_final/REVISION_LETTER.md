# Revision Letter — Paper II, v9 → revised version

**Author:** Hassane Bakkaoui  
**Date:** April 2026

This document lists every substantive change made to the v9 PDF of
*Parametric Prime Families via Quadratic Forms: Layer Invariants,
Conditional Proofs, and Connections to the Riemann Zeta Function*
during the rigorous revision pass.

The aim of the revision was to bring the manuscript to a level
consistent with submission to a number-theory journal: every
quantitative claim must be either (a) proved unconditionally, (b)
proved under a clearly stated hypothesis, or (c) labelled as
heuristic/empirical. No claim should be ambiguous about its status.

---

## 1. Mathematical corrections

### 1.1 Theorem 2.2 (now Theorem 2.2 — `thm:GRH-bound`)

**v9:** stated `|q_min| = O(m log² m)`, sketched proof "via Linnik".

**Issue:** The proof sketch said "Linnik's theorem under GRH" but
Linnik's theorem is *unconditional* (with exponent ≤ 5.2 — recently
≤ 4.95 by Xylouris). What gives `O(m log² m)` is Heath-Brown's
GRH-conditional Linnik bound.

**Revision:**
- Cited Heath-Brown 1992 (PLMS 64) explicitly.
- Reproduced the bound `p ≤ A + C(d) √A (log A)²` precisely.
- Used `A ∼_k k m²` so that the constant in the final `O_k(m log² m)`
  depends explicitly on `k`.

### 1.2 Figure 7 ↔ Theorem 2.2 inconsistency

**v9:** Figure 7 (zeta connection diagram) shows
`GRH ⇒ |q_min| = O(m log m)` while Theorem 2.2 states
`O(m log² m)`. The two statements differ by a factor of `log m`.

**Revision:** The figure (raster image, cannot be edited) is kept
as-is, but the caption explicitly notes that "Level III in this
paper reads `|q_min| = O_k(m log² m)` (Theorem 2.2)".

### 1.3 Hypothesis (H3) was used before being stated

**v9:** Conditional Proposition 9.1 invokes "H3 (the Bateman–Horn
constant `C_f(j)` is effectively independent of j up to an error
`O(1/(m log m))`)" inside the proof, without ever stating H3 as a
formal hypothesis.

**Revision:** Added a numbered `Hypothesis` environment (`hypothesis:H3`)
that states the assumption rigorously *before* the proposition:

> H3: For `|j| ≤ m/2`, the local factors `C_f(j)` at primes `ℓ > 3`
> entering the Bateman–Horn product for `H_m ± 6j` satisfy
> 
> `(1/m) Σ_{|j|≤m/2} |C_f(j) - C_f(0)| = O(1/(m log m))`.

The status note then explains that this is rigorously proved at
ℓ ∈ {2, 3} but unproved for ℓ > 3.

Hypotheses H1 (Bateman–Horn) and GRH are likewise stated formally
before use.

### 1.4 Step 2 of the proof of Proposition 9.1

**v9:** Wrote `(1+o(1))` for the Bateman–Horn density.

**Revision:** Replaced by the quantified
`(1 + O(1/log H_m))`, which is what is actually used in subsequent
steps and what is justified by the explicit-formula error term under
GRH.

### 1.5 Theorem 3.2 (Pocklington certificate)

**v9:** Stated as a theorem but with no reference to the original
Pocklington–Lehmer theorem and no proof.

**Revision:**
- Added explicit citations to Pocklington 1914 and Brillhart–Lehmer–
  Selfridge 1975 (now `LehmerPSW1975`).
- Added a short proof identifying the result as Pocklington–Lehmer
  applied to the explicit factorisation `p − 1 = F · m` with
  `F = 3(m+1)`.
- Stated the smoothness hypothesis `m+1 = 2^a · 3^b · 5^c · ...` on
  `m+1` explicitly as the operational condition.

### 1.6 Conjecture C0 error term

**v9:** Wrote `1 + O(1/ln p)` without justification.

**Revision:** Replaced by the more honest `1 + o(1)` (the conjectured
geometric derivation justifies only `o(1)`, not a quantitative
`O(1/ln p)` rate).

### 1.7 References added

Four references that were used implicitly were missing:

- **Heath-Brown 1992** — needed for the corrected proof of
  Theorem 2.2.
- **Pocklington 1914** — original primality criterion.
- **Brillhart–Lehmer–Selfridge 1975** — modern formulation used in
  Theorem 3.2.
- **Vinogradov 1937** — cited via Iwaniec–Kowalski for the
  Weyl–Vinogradov sums in Section 6.

The bibliography is now self-contained.

---

## 2. Editorial corrections

### 2.1 Notation harmonisation with Paper I

The v9 already explained the parameterisation difference between
Paper I (one-sided `q ≥ 0`) and Paper II (signed `q ∈ Z`). The
revision keeps that explanation in the *Relation to Paper I* box but
also re-states it once at the start of Section 7 to make it
self-contained for a reader who skips the introduction.

### 2.2 Figure cross-references

All figures are now cross-referenced with `\ref{fig:...}` rather than
hardcoded numbers, so the numbering remains coherent if any figure
is added or removed.

### 2.3 Open-problem labels

Open problems O1, O4, O5, O6, O7 are now numbered LaTeX environments
with `\label{}` so that other parts of the text reference them
correctly.

### 2.4 Connection diagram caveat

Section 10 now explicitly says

> *"Important: only the implication GRH ⇒ C1 is established; the
> converse C1 ⇒ GRH is not claimed in this paper."*

(this was in v9 but easy to miss; promoted to bold).

---

## 3. What was *not* changed

The following remain as in v9 (no issue identified):

- All numerical results and tables (verified consistent with the
  reported figures).
- The structure of Sections 1–14 and the four-level zeta connection.
- The statement and content of Negative Results (bias, decomposition,
  spectral exclusion).
- The five Open Problems (their statements were already precise).
- The choice of figures (8 figures, all preserved with the original
  raster images).
- All section titles and the table of contents structure.

---

## 4. Files in this submission

| File | Description |
|------|-------------|
| `paper_II_revised.tex` | Revised LaTeX source |
| `paper_II_revised.pdf` | Compiled PDF (19 pages) |
| `figures/figure_1_gap_law.png` | Universal gap law (Fig. 1 of paper) |
| `figures/figure_2_pocklington.png` | Pocklington pipeline (Fig. 2) |
| `figures/figure_3_C0_universal.png` | C₀(k) universality (Fig. 3) |
| `figures/figure_4_qmin_PNT.png` | q_min vs PNT–AP (Fig. 4) |
| `figures/figure_5_layer_invariant.png` | Layer invariant 0.63 (Fig. 5) |
| `figures/figure_6_corrected_C1C2C3.png` | Three corrected conjectures (Fig. 6) |
| `figures/figure_7_zeta_connection.png` | ζ(s) ↔ family connection (Fig. 7) |
| `figures/figure_8_spurious_I1.png` | Spurious I(1) regression (Fig. 8) |
| `REVISION_LETTER.md` | This document |

---

## 5. Compilation instructions

```bash
cd paper_II_revised/
pdflatex paper_II_revised.tex
pdflatex paper_II_revised.tex   # 2nd pass: ToC + cross-refs
pdflatex paper_II_revised.tex   # 3rd pass: final
```

The compilation produces a 19-page PDF with all 8 figures embedded.
No external bibliographic database is required — the bibliography is
included as `thebibliography` in the source.
